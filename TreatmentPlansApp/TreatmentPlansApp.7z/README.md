# TreatmentPlansApp

This project is based on Treatment Plans CRUD.

## To setup the project.
    Run `npm install` in terminal.

## To run the ProjectSS
    Run `npm start` in terminal.
    The project will be running on `http://localhost:4200`

## About the project
    This project uses majorly Angular Material for development and UI components.